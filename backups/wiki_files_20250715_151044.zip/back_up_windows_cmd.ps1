# Configuration
$BACKUP_DIR = ".\backups"
$TIMESTAMP = Get-Date -Format "yyyyMMdd_HHmmss"
$DB_CONTAINER = "bhilaipedia-database-1"

# Create backup directory
New-Item -ItemType Directory -Force -Path $BACKUP_DIR | Out-Null

# 1. Database Backup
docker exec $DB_CONTAINER mysqldump -u root -pbhilaipedia bhilaipedia | Out-File -FilePath "$BACKUP_DIR\db_$TIMESTAMP.sql" -Encoding UTF8

# 2. Files Backup (Native ZIP)
$FilesToBackup = @(
    ".\mediawiki_data",
    ".\extensions", 
    ".\database_backup.sql",
    ".\LocalSettings.php"
)
Add-Type -Assembly "System.IO.Compression.FileSystem"
[IO.Compression.ZipFile]::CreateFromDirectory(
    ".\", 
    "$BACKUP_DIR\wiki_files_$TIMESTAMP.zip",
    [IO.Compression.CompressionLevel]::Optimal,
    $false, # don't include base dir
    [System.Text.Encoding]::UTF8
)
 