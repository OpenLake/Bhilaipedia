<?php
/**
 * Aliases for the PageOwnership extension
 *
 * @file
 * @ingroup Extensions
 */
$specialPageAliases = [];

/**
 * English
 */
$specialPageAliases['en'] = [
	'PageOwnership' => [ 'PageOwnership' ],
	'PageOwnershipPermissions' => [ 'PageOwnershipPermissions' ],
];
