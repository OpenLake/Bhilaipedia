# PageOwnership

Implements page ownership based on users and groups through a user-friendly interface, supports cache and Semantic MediaWiki

Please check https://www.mediawiki.org/wiki/Extension:PageOwnership for the official documentation.

